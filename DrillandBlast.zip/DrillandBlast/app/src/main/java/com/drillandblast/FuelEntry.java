package com.drillandblast;

/**
 * Created by Zachary on 3/31/2016.
 */
public class FuelEntry {
}
